package com.loginp;

public class Amazon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
